
let vida1 = 100;
let vida2 = 100;
let vida3 = 100;

let turno = 1;
let partidaTerminada = true;

function empezarFunction() {
    vida1 = 100;
    vida2 = 100;
    vida3 = 100;

    turno = 1;
    partidaTerminada = false;

    document.getElementById("vida1").textContent = vida1;
    document.getElementById("vida2").textContent = vida2;
    document.getElementById("vida3").textContent = vida3;

    document.getElementById("marcador").innerHTML = "";

    actualizar();
}

function actualizar() {
    for (let i = 1; i <= 3; i++) {
        let activo = i === turno && !partidaTerminada;

        document.getElementById("atacar" + i).disabled = !activo;
        document.getElementById("pasar" + i).disabled = !activo;
        document.getElementById("objetivo" + i).disabled = !activo;

        if (i === 1) {
            document.getElementById("probabilidad1").disabled = !activo;
        }
    }

    if (!partidaTerminada) {
        document.getElementById("turno").textContent =
            "Turno del Jugador " + turno;
    }
}

function atacar(jugador) {
    if (jugador !== turno || partidaTerminada) return;

    let objetivo = Number(document.getElementById("objetivo" + jugador).value);

    let probabilidad = 90;

    if (jugador === 1) {
        probabilidad = Number(document.getElementById("probabilidad1").value);
    }

    if (jugador === 3) {
        probabilidad = 70;
    }

    let numero = Math.random() * 100;

    if (numero < probabilidad) {
        let dano = Math.floor(Math.random() * 20) + 1;

        if (objetivo === 1) {
            vida1 -= dano;
            document.getElementById("vida1").textContent = Math.max(0, vida1);
        }

        if (objetivo === 2) {
            vida2 -= dano;
            document.getElementById("vida2").textContent = Math.max(0, vida2);
        }

        if (objetivo === 3) {
            vida3 -= dano;
            document.getElementById("vida3").textContent = Math.max(0, vida3);
        }

        document.getElementById("marcador").innerHTML +=
            "<p>Jugador " + jugador + " ha atacado al Jugador " +
            objetivo + " y ha quitado " + dano + " de vida.</p>";

    } else {
        document.getElementById("marcador").innerHTML +=
            "<p>Jugador " + jugador + " ha fallado el ataque.</p>";
    }

    comprobarGanador();

    if (!partidaTerminada) {
        cambiarTurno();
    }
}

function pasar(jugador) {
    if (jugador !== turno || partidaTerminada) return;

    cambiarTurno();
}

function cambiarTurno() {
    turno++;

    if (turno > 3) {
        turno = 1;
    }

    actualizar();
}

function comprobarGanador() {
    let vivos = 0;
    let ganador = 0;

    if (vida1 > 0) {
        vivos++;
        ganador = 1;
    }

    if (vida2 > 0) {
        vivos++;
        ganador = 2;
    }

    if (vida3 > 0) {
        vivos++;
        ganador = 3;
    }

    if (vivos === 1) {
        partidaTerminada = true;

        document.getElementById("turno").textContent =
            "Gana el Jugador " + ganador + "";

        actualizar();
    }
}
